import React from 'react';
import {
  Paper,
  Table,
  TableBody,
  TableCell,
  TableContainer,
  TableHead,
  TableRow,
  Typography,
  Box,
  Chip,
  IconButton,
  Alert,
  Card,
  CardContent
} from '@mui/material';
import { Delete, ExternalLink, Copy, Database } from 'lucide-react';
import { useUrlShortener } from '../hooks/useUrlShortener';

const StatisticsTable: React.FC = () => {
  const { urls, deleteUrl, incrementClickCount } = useUrlShortener();

  const handleCopyUrl = async (shortUrl: string) => {
    try {
      await navigator.clipboard.writeText(shortUrl);
    } catch (err) {
      console.error('Failed to copy URL:', err);
    }
  };

  const handleOpenUrl = (id: string, url: string) => {
    incrementClickCount(id);
    window.open(url, '_blank');
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  if (urls.length === 0) {
    return (
      <Card 
        elevation={0}
        sx={{ 
          background: 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)',
          border: '1px solid #e2e8f0'
        }}
      >
        <CardContent sx={{ p: 6, textAlign: 'center' }}>
          <Box sx={{ mb: 3 }}>
            <Database size={48} color="#6366f1" />
          </Box>
          <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
            No Data Available
          </Typography>
          <Typography variant="body1" color="text.secondary">
            No URLs have been shortened yet. Go to the URL Shortener page to create your first shortened URL and start tracking analytics.
          </Typography>
        </CardContent>
      </Card>
    );
  }

  return (
    <TableContainer 
      component={Paper} 
      elevation={0}
      sx={{ 
        background: 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)',
        border: '1px solid #e2e8f0',
        borderRadius: 3
      }}
    >
      <Table>
        <TableHead>
          <TableRow sx={{ backgroundColor: 'rgba(99, 102, 241, 0.08)' }}>
            <TableCell sx={{ fontWeight: 700, fontSize: '1rem' }}>Short URL</TableCell>
            <TableCell sx={{ fontWeight: 700, fontSize: '1rem' }}>Original URL</TableCell>
            <TableCell sx={{ fontWeight: 700, fontSize: '1rem' }}>Created</TableCell>
            <TableCell sx={{ fontWeight: 700, fontSize: '1rem' }}>Clicks</TableCell>
            <TableCell sx={{ fontWeight: 700, fontSize: '1rem' }}>Source</TableCell>
            <TableCell sx={{ fontWeight: 700, fontSize: '1rem' }}>Location</TableCell>
            <TableCell sx={{ fontWeight: 700, fontSize: '1rem' }}>Actions</TableCell>
          </TableRow>
        </TableHead>
        <TableBody>
          {urls.map((url, index) => (
            <TableRow 
              key={url.id}
              sx={{ 
                '&:hover': { backgroundColor: 'rgba(99, 102, 241, 0.04)' },
                backgroundColor: index % 2 === 0 ? 'transparent' : 'rgba(248, 250, 252, 0.5)'
              }}
            >
              <TableCell>
                <Box sx={{ display: 'flex', alignItems: 'center', gap: 1 }}>
                  <Typography 
                    variant="body2" 
                    sx={{ 
                      fontWeight: 600, 
                      color: 'primary.main',
                      fontSize: '0.95rem'
                    }}
                  >
                    {url.shortUrl}
                  </Typography>
                  <IconButton 
                    size="small" 
                    onClick={() => handleCopyUrl(url.shortUrl)}
                    title="Copy short URL"
                    sx={{ 
                      color: 'primary.main',
                      '&:hover': { backgroundColor: 'primary.light', color: 'white' }
                    }}
                  >
                    <Copy size={14} />
                  </IconButton>
                </Box>
              </TableCell>
              <TableCell>
                <Typography 
                  variant="body2" 
                  sx={{ 
                    maxWidth: 250, 
                    overflow: 'hidden', 
                    textOverflow: 'ellipsis',
                    whiteSpace: 'nowrap',
                    fontSize: '0.9rem'
                  }}
                >
                  {url.originalUrl}
                </Typography>
              </TableCell>
              <TableCell>
                <Typography variant="body2" sx={{ fontSize: '0.9rem' }}>
                  {formatDate(url.createdAt)}
                </Typography>
              </TableCell>
              <TableCell>
                <Chip 
                  label={url.clickCount} 
                  size="small" 
                  color="primary"
                  variant="outlined"
                  sx={{ fontWeight: 600 }}
                />
              </TableCell>
              <TableCell>
                <Chip
                  label={url.source}
                  size="small"
                  color="secondary"
                  variant="outlined"
                  sx={{ fontSize: '0.8rem' }}
                />
              </TableCell>
              <TableCell>
                <Typography variant="body2" sx={{ fontSize: '0.9rem' }}>
                  {url.geoLocation}
                </Typography>
              </TableCell>
              <TableCell>
                <Box sx={{ display: 'flex', gap: 1 }}>
                  <IconButton 
                    size="small" 
                    onClick={() => handleOpenUrl(url.id, url.originalUrl)}
                    title="Open original URL"
                    sx={{ 
                      color: 'success.main',
                      '&:hover': { backgroundColor: 'success.light', color: 'white' }
                    }}
                  >
                    <ExternalLink size={16} />
                  </IconButton>
                  <IconButton 
                    size="small" 
                    onClick={() => deleteUrl(url.id)}
                    title="Delete URL"
                    sx={{ 
                      color: 'error.main',
                      '&:hover': { backgroundColor: 'error.light', color: 'white' }
                    }}
                  >
                    <Delete size={16} />
                  </IconButton>
                </Box>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </TableContainer>
  );
};

export default StatisticsTable;