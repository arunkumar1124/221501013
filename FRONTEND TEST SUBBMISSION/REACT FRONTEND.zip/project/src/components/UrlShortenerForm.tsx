import React, { useState } from 'react';
import {
  Box,
  TextField,
  Button,
  Paper,
  Typography,
  Alert,
  CircularProgress,
  Snackbar,
  InputAdornment
} from '@mui/material';
import { Link as LinkIcon, Zap } from 'lucide-react';
import { isValidUrl } from '../utils/urlValidator';
import { useUrlShortener } from '../hooks/useUrlShortener';

const UrlShortenerForm: React.FC = () => {
  const [url, setUrl] = useState('');
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState('');
  const [success, setSuccess] = useState(false);
  const { addUrl, urls } = useUrlShortener();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    
    if (!url.trim()) {
      setError('Please enter a URL');
      return;
    }

    if (!isValidUrl(url)) {
      setError('Please enter a valid URL (must include http:// or https://)');
      return;
    }

    setLoading(true);
    
    // Simulate API call delay
    setTimeout(() => {
      try {
        addUrl(url);
        setUrl('');
        setSuccess(true);
        setLoading(false);
      } catch (err) {
        setError('Failed to shorten URL. Please try again.');
        setLoading(false);
      }
    }, 1000);
  };

  return (
    <Paper 
      elevation={0} 
      sx={{ 
        p: 6, 
        maxWidth: 700, 
        mx: 'auto',
        background: 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)',
        border: '1px solid #e2e8f0'
      }}
    >
      <Box sx={{ display: 'flex', alignItems: 'center', mb: 4, justifyContent: 'center' }}>
        <Box sx={{ 
          display: 'flex', 
          alignItems: 'center', 
          gap: 2,
          p: 2,
          borderRadius: 2,
          background: 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)',
          color: 'white'
        }}>
          <Zap size={28} />
          <Typography variant="h4" component="h1" sx={{ fontWeight: 700 }}>
            Shorten Your URL
          </Typography>
        </Box>
      </Box>
      
      <Typography 
        variant="body1" 
        color="text.secondary" 
        sx={{ mb: 4, textAlign: 'center', fontSize: '1.1rem' }}
      >
        Transform long URLs into short, shareable links instantly. No limits, unlimited URLs!
      </Typography>

      <Box component="form" onSubmit={handleSubmit} sx={{ mb: 3 }}>
        <TextField
          fullWidth
          label="Enter URL to shorten"
          value={url}
          onChange={(e) => setUrl(e.target.value)}
          placeholder="https://example.com/very-long-url-that-needs-shortening"
          variant="outlined"
          sx={{ 
            mb: 3,
            '& .MuiOutlinedInput-root': {
              fontSize: '1.1rem',
              py: 0.5
            }
          }}
          disabled={loading}
          error={!!error}
          helperText={error}
          InputProps={{
            startAdornment: (
              <InputAdornment position="start">
                <LinkIcon size={20} color="#6366f1" />
              </InputAdornment>
            ),
          }}
        />
        
        <Box sx={{ display: 'flex', justifyContent: 'center', alignItems: 'center', gap: 3 }}>
          <Button
            type="submit"
            variant="contained"
            disabled={loading}
            sx={{ 
              minWidth: 160,
              py: 1.5,
              fontSize: '1.1rem',
              background: 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)',
              '&:hover': {
                background: 'linear-gradient(135deg, #4f46e5 0%, #7c3aed 100%)',
              }
            }}
          >
            {loading ? <CircularProgress size={24} color="inherit" /> : 'Shorten URL'}
          </Button>
          
          <Typography variant="body2" color="text.secondary" sx={{ fontSize: '1rem' }}>
            {urls.length} URLs created
          </Typography>
        </Box>
      </Box>

      <Snackbar
        open={success}
        autoHideDuration={4000}
        onClose={() => setSuccess(false)}
        anchorOrigin={{ vertical: 'top', horizontal: 'center' }}
      >
        <Alert 
          severity="success" 
          onClose={() => setSuccess(false)}
          sx={{ fontSize: '1rem' }}
        >
          🎉 URL shortened successfully!
        </Alert>
      </Snackbar>
    </Paper>
  );
};

export default UrlShortenerForm;