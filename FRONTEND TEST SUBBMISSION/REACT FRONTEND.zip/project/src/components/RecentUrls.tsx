import React from 'react';
import {
  Box,
  Paper,
  Typography,
  List,
  ListItem,
  ListItemText,
  IconButton,
  Chip,
  Divider,
  Card,
  CardContent
} from '@mui/material';
import { Copy, ExternalLink, TrendingUp } from 'lucide-react';
import { useUrlShortener } from '../hooks/useUrlShortener';

const RecentUrls: React.FC = () => {
  const { urls, incrementClickCount } = useUrlShortener();

  const handleCopyUrl = async (shortUrl: string) => {
    try {
      await navigator.clipboard.writeText(shortUrl);
    } catch (err) {
      console.error('Failed to copy URL:', err);
    }
  };

  const handleOpenUrl = (id: string, url: string) => {
    incrementClickCount(id);
    window.open(url, '_blank');
  };

  if (urls.length === 0) {
    return (
      <Card 
        elevation={0} 
        sx={{ 
          maxWidth: 700, 
          mx: 'auto', 
          mt: 6,
          background: 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)',
          border: '1px solid #e2e8f0'
        }}
      >
        <CardContent sx={{ p: 6, textAlign: 'center' }}>
          <Box sx={{ mb: 3 }}>
            <TrendingUp size={48} color="#6366f1" />
          </Box>
          <Typography variant="h6" gutterBottom sx={{ fontWeight: 600 }}>
            Your Shortened URLs
          </Typography>
          <Typography variant="body1" color="text.secondary">
            No URLs shortened yet. Create your first shortened URL above to get started!
          </Typography>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card 
      elevation={0} 
      sx={{ 
        maxWidth: 700, 
        mx: 'auto', 
        mt: 6,
        background: 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)',
        border: '1px solid #e2e8f0'
      }}
    >
      <CardContent sx={{ p: 4 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, mb: 3 }}>
          <TrendingUp size={24} color="#6366f1" />
          <Typography variant="h6" sx={{ fontWeight: 600 }}>
            Your Shortened URLs ({urls.length})
          </Typography>
        </Box>
        
        <List sx={{ p: 0 }}>
          {urls.map((urlItem, index) => (
            <React.Fragment key={urlItem.id}>
              <ListItem 
                sx={{ 
                  px: 0, 
                  py: 2,
                  '&:hover': {
                    backgroundColor: 'rgba(99, 102, 241, 0.04)',
                    borderRadius: 2
                  }
                }}
              >
                <ListItemText
                  primary={
                    <Box sx={{ display: 'flex', alignItems: 'center', gap: 2, flexWrap: 'wrap', mb: 1 }}>
                      <Typography 
                        variant="body1" 
                        component="span" 
                        sx={{ 
                          fontWeight: 600,
                          color: 'primary.main',
                          fontSize: '1.1rem'
                        }}
                      >
                        {urlItem.shortUrl}
                      </Typography>
                      <Chip 
                        label={`${urlItem.clickCount} clicks`} 
                        size="small" 
                        color="primary"
                        variant="outlined"
                        sx={{ fontWeight: 500 }}
                      />
                    </Box>
                  }
                  secondary={
                    <Typography 
                      variant="body2" 
                      color="text.secondary" 
                      sx={{ 
                        wordBreak: 'break-all',
                        fontSize: '0.95rem',
                        lineHeight: 1.4
                      }}
                    >
                      {urlItem.originalUrl}
                    </Typography>
                  }
                />
                <Box sx={{ display: 'flex', gap: 1, ml: 2 }}>
                  <IconButton 
                    size="small" 
                    onClick={() => handleCopyUrl(urlItem.shortUrl)}
                    title="Copy short URL"
                    sx={{ 
                      color: 'primary.main',
                      '&:hover': { backgroundColor: 'primary.light', color: 'white' }
                    }}
                  >
                    <Copy size={18} />
                  </IconButton>
                  <IconButton 
                    size="small" 
                    onClick={() => handleOpenUrl(urlItem.id, urlItem.originalUrl)}
                    title="Open original URL"
                    sx={{ 
                      color: 'success.main',
                      '&:hover': { backgroundColor: 'success.light', color: 'white' }
                    }}
                  >
                    <ExternalLink size={18} />
                  </IconButton>
                </Box>
              </ListItem>
              {index < urls.length - 1 && <Divider sx={{ my: 1 }} />}
            </React.Fragment>
          ))}
        </List>
      </CardContent>
    </Card>
  );
};

export default RecentUrls;