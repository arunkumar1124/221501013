import React from 'react';
import { Tabs, Tab, Box } from '@mui/material';
import { Link as RouterLink, useLocation } from 'react-router-dom';
import { LinkIcon, BarChart3Icon } from 'lucide-react';

const Navigation: React.FC = () => {
  const location = useLocation();
  
  const getTabValue = () => {
    if (location.pathname === '/') return 0;
    if (location.pathname === '/statistics') return 1;
    return 0;
  };

  return (
    <Box sx={{ 
      '& .MuiTabs-root': { 
        minHeight: 'auto',
      },
      '& .MuiTab-root': { 
        color: 'rgba(255, 255, 255, 0.8)',
        fontWeight: 600,
        textTransform: 'none',
        fontSize: '1rem',
        minHeight: 'auto',
        py: 1,
        '&.Mui-selected': {
          color: 'white',
        }
      },
      '& .MuiTabs-indicator': {
        backgroundColor: 'white',
        height: 3,
        borderRadius: '3px 3px 0 0'
      }
    }}>
      <Tabs value={getTabValue()}>
        <Tab 
          label="URL Shortener" 
          component={RouterLink} 
          to="/" 
          icon={<LinkIcon size={18} />}
          iconPosition="start"
        />
        <Tab 
          label="Analytics" 
          component={RouterLink} 
          to="/statistics" 
          icon={<BarChart3Icon size={18} />}
          iconPosition="start"
        />
      </Tabs>
    </Box>
  );
};

export default Navigation;