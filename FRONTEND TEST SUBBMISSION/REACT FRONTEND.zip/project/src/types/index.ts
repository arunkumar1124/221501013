export interface ShortenedUrl {
  id: string;
  originalUrl: string;
  shortUrl: string;
  createdAt: Date;
  clickCount: number;
  source: string;
  geoLocation: string;
}