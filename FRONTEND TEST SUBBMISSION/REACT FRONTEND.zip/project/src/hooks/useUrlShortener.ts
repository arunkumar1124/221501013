import { useState, useEffect } from 'react';
import { ShortenedUrl } from '../types';
import { generateShortUrl, generateMockAnalytics } from '../utils/urlValidator';

export const useUrlShortener = () => {
  const [urls, setUrls] = useState<ShortenedUrl[]>([]);

  useEffect(() => {
    const savedUrls = localStorage.getItem('shortenedUrls');
    if (savedUrls) {
      const parsedUrls = JSON.parse(savedUrls);
      // Convert date strings back to Date objects
      const urlsWithDates = parsedUrls.map((url: any) => ({
        ...url,
        createdAt: new Date(url.createdAt)
      }));
      setUrls(urlsWithDates);
    }
  }, []);

  const saveUrls = (newUrls: ShortenedUrl[]) => {
    localStorage.setItem('shortenedUrls', JSON.stringify(newUrls));
    setUrls(newUrls);
  };

  const addUrl = (originalUrl: string): ShortenedUrl => {
    const analytics = generateMockAnalytics();
    const newUrl: ShortenedUrl = {
      id: Date.now().toString(),
      originalUrl,
      shortUrl: generateShortUrl(),
      createdAt: new Date(),
      ...analytics
    };

    const newUrls = [...urls, newUrl];
    saveUrls(newUrls);
    return newUrl;
  };

  const incrementClickCount = (id: string) => {
    const updatedUrls = urls.map(url => 
      url.id === id ? { ...url, clickCount: url.clickCount + 1 } : url
    );
    saveUrls(updatedUrls);
  };

  const deleteUrl = (id: string) => {
    const newUrls = urls.filter(url => url.id !== id);
    saveUrls(newUrls);
  };

  return {
    urls,
    addUrl,
    incrementClickCount,
    deleteUrl
  };
};