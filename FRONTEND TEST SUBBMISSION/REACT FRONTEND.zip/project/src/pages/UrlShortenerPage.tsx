import React from 'react';
import { Box, Typography } from '@mui/material';
import { Zap } from 'lucide-react';
import UrlShortenerForm from '../components/UrlShortenerForm';
import RecentUrls from '../components/RecentUrls';

const UrlShortenerPage: React.FC = () => {
  return (
    <Box>
      <Box sx={{ textAlign: 'center', mb: 6 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 2, mb: 2 }}>
          <Zap size={32} color="#6366f1" />
          <Typography 
            variant="h4" 
            component="h1" 
            sx={{ fontWeight: 700, color: 'text.primary' }}
          >
            URL Shortener
          </Typography>
        </Box>
        <Typography variant="body1" color="text.secondary" sx={{ fontSize: '1.1rem' }}>
          Create unlimited short links instantly - no restrictions, no limits
        </Typography>
      </Box>
      <UrlShortenerForm />
      <RecentUrls />
    </Box>
  );
};

export default UrlShortenerPage;