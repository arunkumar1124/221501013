import React from 'react';
import { Box, Typography, Grid, Card, CardContent } from '@mui/material';
import { BarChart3, Link, MousePointer, Globe, TrendingUp } from 'lucide-react';
import StatisticsTable from '../components/StatisticsTable';
import { useUrlShortener } from '../hooks/useUrlShortener';

const StatisticsPage: React.FC = () => {
  const { urls } = useUrlShortener();

  const totalClicks = urls.reduce((sum, url) => sum + url.clickCount, 0);
  const averageClicks = urls.length > 0 ? Math.round(totalClicks / urls.length) : 0;

  const stats = [
    {
      title: 'Total URLs',
      value: urls.length,
      icon: <Link size={28} />,
      color: 'primary.main',
      gradient: 'linear-gradient(135deg, #6366f1 0%, #8b5cf6 100%)'
    },
    {
      title: 'Total Clicks',
      value: totalClicks,
      icon: <MousePointer size={28} />,
      color: 'success.main',
      gradient: 'linear-gradient(135deg, #10b981 0%, #059669 100%)'
    },
    {
      title: 'Average Clicks',
      value: averageClicks,
      icon: <BarChart3 size={28} />,
      color: 'info.main',
      gradient: 'linear-gradient(135deg, #3b82f6 0%, #2563eb 100%)'
    },
    {
      title: 'Active URLs',
      value: urls.filter(url => url.clickCount > 0).length,
      icon: <Globe size={28} />,
      color: 'warning.main',
      gradient: 'linear-gradient(135deg, #f59e0b 0%, #d97706 100%)'
    }
  ];

  return (
    <Box>
      <Box sx={{ textAlign: 'center', mb: 6 }}>
        <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 2, mb: 2 }}>
          <TrendingUp size={32} color="#6366f1" />
          <Typography 
            variant="h4" 
            component="h1" 
            sx={{ fontWeight: 700, color: 'text.primary' }}
          >
            Analytics Dashboard
          </Typography>
        </Box>
        <Typography variant="body1" color="text.secondary" sx={{ fontSize: '1.1rem' }}>
          Track performance and insights for all your shortened URLs
        </Typography>
      </Box>
      
      <Grid container spacing={4} sx={{ mb: 6 }}>
        {stats.map((stat, index) => (
          <Grid item xs={12} sm={6} md={3} key={index}>
            <Card 
              elevation={0}
              sx={{ 
                background: stat.gradient,
                color: 'white',
                border: '1px solid rgba(255, 255, 255, 0.1)',
                transition: 'transform 0.2s ease-in-out',
                '&:hover': {
                  transform: 'translateY(-4px)'
                }
              }}
            >
              <CardContent sx={{ p: 3 }}>
                <Box sx={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between' }}>
                  <Box>
                    <Typography 
                      variant="h3" 
                      component="div" 
                      sx={{ 
                        fontWeight: 700,
                        mb: 1,
                        color: 'white'
                      }}
                    >
                      {stat.value}
                    </Typography>
                    <Typography 
                      variant="body1" 
                      sx={{ 
                        color: 'rgba(255, 255, 255, 0.9)',
                        fontWeight: 500
                      }}
                    >
                      {stat.title}
                    </Typography>
                  </Box>
                  <Box sx={{ opacity: 0.8 }}>
                    {stat.icon}
                  </Box>
                </Box>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      <Card 
        elevation={0} 
        sx={{ 
          background: 'linear-gradient(135deg, #ffffff 0%, #f8fafc 100%)',
          border: '1px solid #e2e8f0'
        }}
      >
        <CardContent sx={{ p: 4 }}>
          <Typography 
            variant="h6" 
            gutterBottom 
            sx={{ 
              fontWeight: 600,
              mb: 3,
              display: 'flex',
              alignItems: 'center',
              gap: 2
            }}
          >
            <BarChart3 size={24} color="#6366f1" />
            Detailed Analytics
          </Typography>
          <StatisticsTable />
        </CardContent>
      </Card>
    </Box>
  );
};

export default StatisticsPage;