export const isValidUrl = (url: string): boolean => {
  try {
    const urlObject = new URL(url);
    return urlObject.protocol === 'http:' || urlObject.protocol === 'https:';
  } catch {
    return false;
  }
};

export const generateShortUrl = (): string => {
  const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
  let result = '';
  for (let i = 0; i < 6; i++) {
    result += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return `https://short.ly/${result}`;
};

export const generateMockAnalytics = () => ({
  clickCount: Math.floor(Math.random() * 100),
  source: ['Google', 'Facebook', 'Twitter', 'Direct', 'LinkedIn'][Math.floor(Math.random() * 5)],
  geoLocation: ['New York, USA', 'London, UK', 'Tokyo, Japan', 'Mumbai, India', 'Sydney, Australia'][Math.floor(Math.random() * 5)]
});